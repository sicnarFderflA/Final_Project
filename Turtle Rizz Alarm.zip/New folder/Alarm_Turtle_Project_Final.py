import pygame
import turtle
import os

class TurtleRizzAlarm:
    def __init__(self):
        self.hours, self.minutes, self.seconds = 0, 0, 0
        pygame.init()
        self.setup()

    def restart(self, x, y):
        self.hours, self.minutes, self.seconds = 0, 0, 0
        pygame.mixer.music.stop()
        turtle.clearscreen()
        self.setup()

    def alarm_sound(self):
        #for .exe
        sound_file = os.path.abspath("sound/rizz_song.mp3")
        #for .py
        #sound_file = os.path.abspath("D:/Codings/Turtle Rizz Alarm/dist/sound/rizz_song.mp3")
        pygame.mixer.music.load(sound_file)
        pygame.mixer.music.play()
        pygame.mixer.music.set_volume(10)

    def start(self, x, y):
        self.alarm2.speed(1)
        self.alarm2.left(180)
        self.welcome.undo()
        self.alarm2.forward(250)
        self.alarm2.right(180)
        self.alarm.goto(-250, 0)
        self.alarm.showturtle()
        self.alarm.speed(1)
        self.alarm2.hideturtle()
        self.startb.showturtle()
        self.text.write("Press the Button to start.", align="center", font=("Arial", 14, "normal"))
        self.ui_time()

    def alarm_stop(self, x, y):
        pygame.mixer.music.stop()
        self.snoozeb.hideturtle()
        self.snooze.clear()
        self.stime = 0

    def snoozef(self, x, y):
        self.hours = 0
        self.seconds = 0
        self.minutes = 5
        self.snoozeb.hideturtle()
        self.snooze.clear()
        self.snooze.write("Snoozed for 5 minutes", align="center", font=("Arial", 14, "normal"))
        pygame.mixer.music.stop()
        self.alarm.left(180)
        self.alarm.forward(500)
        self.alarm.right(180)
        self.move_turtle(x, y)

    def ui_time(self):
        def update_time():
            self.timer.clear()
            self.timer.write(f"{self.hours:02d}:{self.minutes:02d}:{self.seconds:02d}", align="center",
                             font=("Arial", 25, "normal"))

        def increase_hours(x, y):
            self.hours = (self.hours + 1) % 24
            update_time()

        def decrease_hours(x, y):
            self.hours = (self.hours - 1) % 24
            update_time()

        def increase_minutes(x, y):
            self.minutes = (self.minutes + 1) % 60
            update_time()

        def decrease_minutes(x, y):
            self.minutes = (self.minutes - 1) % 60
            update_time()

        def increase_seconds(x, y):
            self.seconds = (self.seconds + 1) % 60
            update_time()

        def decrease_seconds(x, y):
            self.seconds = (self.seconds - 1) % 60
            update_time()

        self.timer = turtle.Turtle()
        self.timer.hideturtle()
        self.timer.penup()
        self.timer.goto(0, 80)
        self.timer.write(f"{self.hours:02d}:{self.minutes:02d}:{self.seconds:02d}", align="center",
                         font=("Arial", 25, "normal"))

        self.arrow_hour_up = turtle.Turtle()
        self.arrow_hour_up.speed(0)
        self.arrow_hour_up.shape("arrow")
        self.arrow_hour_up.color("black")
        self.arrow_hour_up.penup()
        self.arrow_hour_up.goto(-45, 120)
        self.arrow_hour_up.setheading(90)
        self.arrow_hour_up.onclick(increase_hours)

        self.arrow_hour_down = self.arrow_hour_up.clone()
        self.arrow_hour_down.speed(0)
        self.arrow_hour_down.color("black")
        self.arrow_hour_down.goto(-45, 80)
        self.arrow_hour_down.setheading(-90)
        self.arrow_hour_down.onclick(decrease_hours)

        self.arrow_minute_up = self.arrow_hour_up.clone()
        self.arrow_minute_up.speed(0)
        self.arrow_minute_up.color("black")
        self.arrow_minute_up.goto(0, 120)
        self.arrow_minute_up.onclick(increase_minutes)

        self.arrow_minute_down = self.arrow_hour_down.clone()
        self.arrow_minute_down.speed(0)
        self.arrow_minute_down.color("black")
        self.arrow_minute_down.goto(0, 80)
        self.arrow_minute_down.onclick(decrease_minutes)

        self.arrow_second_up = self.arrow_hour_up.clone()
        self.arrow_second_up.speed(0)
        self.arrow_second_up.color("black")
        self.arrow_second_up.goto(45, 120)
        self.arrow_second_up.onclick(increase_seconds)

        self.arrow_second_down = self.arrow_hour_down.clone()
        self.arrow_second_down.speed(0)
        self.arrow_second_down.color("black")
        self.arrow_second_down.goto(45, 80)
        self.arrow_second_down.onclick(decrease_seconds)

        turtle.listen()
        self.startb.onclick(self.move_turtle)

    def move_turtle(self, x, y):
        if self.hours == 0 and self.minutes == 0 and self.seconds == 0:
            self.zerotime.write("Enter Time", align="center", font=("Arial", 14, "normal"))
            return
        
        self.arrow_hour_up.hideturtle()
        self.arrow_hour_down.hideturtle()
        self.arrow_minute_up.hideturtle()
        self.arrow_minute_down.hideturtle()
        self.arrow_second_up.hideturtle()
        self.arrow_second_down.hideturtle()
        self.startb.hideturtle()
        self.text.undo()

        self.stime = (self.hours * 3600) + (self.minutes * 60) + self.seconds
        remaining_time = self.stime

        def countdown():
            nonlocal remaining_time
            self.zerotime.clear()
            self.stop.clear()
            self.stop.write("Stop", align="center", font=("Arial", 14, "normal"))
            self.bstop.showturtle()
            self.bstop.onclick(self.alarm_stop)

            if remaining_time > 0:
                remaining_time -= 1

                hrs = remaining_time // 3600
                mins = (remaining_time % 3600) // 60
                secs = remaining_time % 60

                self.timer.clear()
                self.timer.write(f"{hrs:02d}:{mins:02d}:{secs:02d}", align="center", font=("Arial", 25, "normal"))

                if self.stime != 0:
                    self.alarm.forward(500 / self.stime)
                    self.timer.getscreen().ontimer(countdown, 1000)
                else:
                    self.timer.clear()
                    self.timer.write("You Stopped the Turtle Rizz Alarm.", align="center", font=("Arial", 14, "normal"))
                    
                    
            else:
                self.alarm_sound()
                self.timer.clear()
                self.timer.write("Times up!", align="center", font=("Arial", 25, "normal"))
                self.snooze.clear()
                self.snooze.write("Snooze", align="center", font=("Arial", 14, "normal"))
                self.snoozeb.showturtle()
                self.snoozeb.onclick(self.snoozef)

        countdown()

    def setup(self):
        self.ui = turtle.Screen()
        self.ui.title("Turtle Rizz Alarm")
        self.ui.bgcolor("#C2b280")
        self.ui.setup(width=800, height=350)

        self.welcome = turtle.Turtle()
        self.welcome.hideturtle()
        self.welcome.penup()
        self.welcome.goto(0, 80)
        self.welcome.write("Welcome to Turtle Alarm\nPress the Turtle to continue", align="center",
                            font=("Arial", 16, "normal"))

        self.startb = turtle.Turtle()
        self.startb.shape("circle")
        self.startb.color("green")
        self.startb.penup()
        self.startb.goto(-116, -68)
        self.startb.hideturtle()

        self.text = turtle.Turtle()
        self.text.penup()
        self.text.hideturtle()
        self.text.goto(0, -80)

        self.alarm = turtle.Turtle()
        self.alarm.turtlesize(5)
        self.alarm.shape("turtle")
        self.alarm.color("green")
        self.alarm.penup()
        self.alarm.speed(0)
        self.alarm.hideturtle()

        self.alarm2 = turtle.Turtle()
        self.alarm2.turtlesize(5)
        self.alarm2.shape("turtle")
        self.alarm2.color("green")
        self.alarm2.penup()
        self.alarm2.speed(0)
        self.alarm2.onclick(self.start)

        blue = turtle.Turtle()
        blue.hideturtle()
        blue.speed(0)
        blue.penup()
        blue.fillcolor("blue")
        blue.goto(255, 175)
        blue.begin_fill()
        blue.pendown()
        for _ in range(9):
            blue.right(180)
            blue.circle(10, 180)
            blue.left(180)
            blue.circle(10, -180)
        blue.goto(400, -185)
        blue.goto(400, 175)
        blue.goto(255, 175)
        blue.end_fill()

        wave = turtle.Turtle()
        wave.hideturtle()
        wave.speed(0)
        wave.penup()
        wave.fillcolor("white")
        wave.goto(250, 175)
        wave.begin_fill()
        wave.pendown()
        for _ in range(9):
            wave.right(180)
            wave.circle(10, 180)
            wave.left(180)
            wave.circle(10, -180)
        wave.penup()
        wave.goto(250, 175)
        wave.pendown()
        wave.forward(10)
        for _ in range(9):
            wave.right(180)
            wave.circle(10, 180)
            wave.left(180)
            wave.circle(10, -180)
        wave.backward(10)
        wave.end_fill()
        wave.penup()

        restartb = turtle.Turtle()
        restartb.penup()
        restartb.goto(-375, 150)
        restartb.shape("circle")
        restartb.onclick(self.restart)

        restartt = turtle.Turtle()
        restartt.penup()
        restartt.goto(-335, 142)
        restartt.hideturtle()
        restartt.write("Restart", align="center", font=("Arial", 12, "normal"))

        self.snooze, self.snoozeb, self.bstop, self.stop = turtle.Turtle(), turtle.Turtle(), turtle.Turtle(), turtle.Turtle()
        self.snooze.hideturtle()
        self.snooze.penup()
        self.snooze.goto(0, -80)
        self.snoozeb.hideturtle()
        self.snoozeb.color("green")
        self.snoozeb.shape("circle")
        self.snoozeb.penup()
        self.snoozeb.goto(-45, -70)
        self.snoozeb.speed(0)
        self.snooze.speed(0)
        self.stop.hideturtle()
        self.stop.penup()
        self.stop.goto(0, -110)
        self.bstop.hideturtle()
        self.bstop.shape("circle")
        self.bstop.penup()
        self.bstop.goto(-35, -100)
        self.bstop.color("red")

        self.zerotime = turtle.Turtle()
        self.zerotime.hideturtle()
        self.zerotime.penup()
        self.zerotime.goto(0, -60)




if __name__ == "__main__":
    turtle_rizz_alarm = TurtleRizzAlarm()
    turtle.mainloop()